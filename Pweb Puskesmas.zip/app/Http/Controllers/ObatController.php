<?php

namespace App\Http\Controllers;

use App\Models\Obat;
use Illuminate\Http\Request;
use Symfony\Component\CssSelector\Node\FunctionNode;

class ObatController extends Controller
{
    public function index()
    {
        $obat = Obat::all();
        return view('obat.index',compact(['obat']));
    }
    public function create()
    {
        return view('obat.create');
    }
    public function store(Request $request)
    {
        Obat::create($request->except(['_token','submit']));
        return redirect('/obat');
    }
    public function edit($id)
    {
        $obat = Obat::find($id);
        return view('obat.edit',compact(['obat']));
    }
    public function update($id, Request $request)
    {
        $obat = Obat::find($id);
        $obat->update($request->except(['token','submit']));
        return redirect('/obat');
    }
    public function destroy($id)
    {
        $obat = Obat::find($id);
        $obat->delete();
        return redirect('/obat');
    }
}
