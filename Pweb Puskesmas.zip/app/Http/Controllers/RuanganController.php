<?php

namespace App\Http\Controllers;

use App\Models\Ruangan;
use Illuminate\Http\Request;

class RuanganController extends Controller
{
    public function index(){
        $ruangan = Ruangan::all();
        return view('ruangan.index',compact(['ruangan']));
    }
    public function create()
    {
        return view('ruangan.create');
    }
    public function store(Request $request)
    {
        Ruangan::create($request->except('_token','submit'));
        return redirect('/ruangan');
    }
    public function edit($id)
    {
        $ruangan = Ruangan::find($id);
        return view('ruangan.edit',compact(['ruangan']));
    }
    public function update($id, Request $request)
    {
        $ruangan = Ruangan::find($id);
        $ruangan->update($request->except(['token','submit']));
        return redirect('/ruangan');
    }
    public function destroy($id)
    {
        $ruangan = Ruangan::find($id);
        $ruangan->delete();
        return redirect('/raungan');
    }
}
