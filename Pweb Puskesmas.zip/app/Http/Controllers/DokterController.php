<?php

namespace App\Http\Controllers;

use App\Models\Dokter;
use Illuminate\Http\Request;

class DokterController extends Controller
{
    public function index(){
        $dokter = Dokter::all();
        return view('dokter.index',compact(['dokter']));
    }
    public function create()
    {
        return view('dokter.create');
    }
    public function store(Request $request)
    {
        Dokter::create($request->except(['_token','submit']));
        return redirect('/dokter');
    }
    public function edit($id)
    {
        $dokter = Dokter::find($id);
        return view('dokter.edit',compact(['dokter']));
    }
    public function update($id, Request $request)
    {
        $dokter = Dokter::find($id);
        $dokter->update($request->except('_token','submit'));
        return redirect('/dokter');
    }
    public function destroy($id)
    {
        $dokter = Dokter::find($id);
        $dokter->delete();
        return redirect('/dokter');
    }
}
