@extends('layout.master')

@section('content')
<nav class="navbar navbar-expand-sm bg-success navbar-light">
		<div class="container-fluid">
		    <ul class="navbar-nav nav-tabs">
                <!-- LINK DOKTER -->

		      	<li class="nav-item" >
		        	<a id="dokter" class="nav-link" href="/dokter">Dokter</a>
		      	</li>

		      	<!-- LINK PASIEN -->

		     	<li class="nav-item">
		        	<a id="pasien" class="nav-link active" href="/pasien" >Pasien</a>
		      	</li>
		      	
		      	<!-- LINK OBAT -->

		      	<li class="nav-item">
		        	<a id="obat" class="nav-link" href="/obat">Obat</a>
		      	</li>
		      	
		      	<!-- LINK RUANGAN -->

		      	<li class="nav-item">
		        	<a id="ruangan" class="nav-link" href="/ruangan">Ruangan</a>
		      	</li>
		    </ul>
		</div>
	</nav>
<p></p>
<div class="row bg-light text-dark" style="margin-right: 30px; margin-left: 30px; border: solid 1px lightgreen;">
  	<div class="col" style="border-right: solid 1px lightgreen;">
<h4>Edit Data Pasien</h4>
<form action="/pasien/{{$pasien->id}}" method="POST">
    @method('put')
    @csrf
<div class="mb-3 mt-3">
    	<label for="id_pasien" class="form-label">Id Pasien:</label>
    	<input type="id_pasien" class="form-control" id="id_pasien" placeholder="id Pasien" name="id_pasien" value="{{$pasien->id_pasien}}">
  	</div>

  	<!--INPUT NAMA PASIEN-->

  	<div class="mb-3">
    	<label for="nama_pasien" class="form-pasien">Nama Pasien</label>
    	<input type="nama_pasien" class="form-control" id="nama_pasien" placeholder="Nama Pasien" name="nama_pasien" value="{{$pasien->nama_pasien}}">
  	</div>
  	
  	<!--INPUT ALAMAT PASIEN-->

  	<div class="mb-3">
    	<label for="alamat_pasien" class="form-label">Alamat Pasien</label>
    	<input type="alamat_pasien" class="form-control" id="alamat_pasien" placeholder="Alamat Pasien" name="alamat_pasien" value="{{$pasien->alamat_pasien}}">
  	</div>
  	
  	<!--INPUT HP PASIEN-->

  	<div class="mb-3">
    	<label for="hp_pasien" class="form-label">Hp Pasien</label>
    	<input type="hp_pasien" class="form-control" id="hp_pasien" placeholder="Hp Pasien" name="hp_pasien" value="{{$pasien->hp_pasien}}">
  	</div>

  	<!--INPUT TANGGAL LAHIR PASIEN-->

  	<div class="mb-3">
    	<label for="tgl_pasien" class="form-label">Tanggal Lahir Pasien</label>
    	<input type="date" class="form-control" id="tgl_pasien" placeholder="Tanggal Lahir Pasien" name="tgl_lahir_pasien" value="{{$pasien->tgl_lahir_pasien}}">
  	</div>
    
    <!--CHECK JENIS KELAMIN DOKTER-->

  	<div class="mb-3">
    	<label for="jenis_kelamin" class="form-label">Jenis Kelamin</label>
    	<select name="jenis_kelamin">
  		<option value="">Pilih Jenis Kelamin</option>
  		<option value="1">Laki-laki</option>
  		<option value="2">Perempuan</option>
        </select>
  	</div>

  	<!--INPUT RIWAYAT PENYAKIT-->

	<div class="mb-3">
    	<label for="riwayat_penyakit" class="form-label">Riwayat Penyakit Diderita</label>
    	<input type="riwayat_penyakit" class="form-control" id="riwayat_penyakit" placeholder="Riwayat Penyakit" name="riwayat_penyakit" value="{{$pasien->riwayat_penyakit}}">
  	</div>

	<!--INPUT DOKTER/PERAWAT-->

  	<div class="mb-3">
    	<label for="dok/per" class="form-label">Dokter/Perawat</label>
    	<input type="dok/per" class="form-control" id="dok/per" placeholder="Dokter/Perawat" name="perawat" value="{{$pasien->perawat}}">
  	</div>

  	<!--INPUT OBAT-->

  	<div class="mb-3">
    	<label for="obat" class="form-label">Obat</label>
    	<input type="obat" class="form-control" id="obat" placeholder="Obat" name="obat" value="{{$pasien->obat}}">
  	</div>
      <input type="submit" name="submit" value="Update">
</form>
@endsection