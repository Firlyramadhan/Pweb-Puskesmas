@extends('layout.master')

@section('content')
<nav class="navbar navbar-expand-sm bg-success navbar-light">
		<div class="container-fluid">
		    <ul class="navbar-nav nav-tabs">

		    	<!-- LINK DOKTER -->

		      	<li class="nav-item" >
		        	<a class="nav-link" href="/dokter">Dokter</a>
		      	</li>

		      	<!-- LINK PASIEN -->

		     	<li class="nav-item">
		        	<a id="pasien" class="nav-link" href="/pasien">Pasien</a>
		      	</li>
		      	
		      	<!-- LINK OBAT -->

		      	<li class="nav-item">
		        	<a id="obat" class="nav-link" href="/obat">Obat</a>
		      	</li>
		      	
		      	<!-- LINK RUANGAN -->

		      	<li class="nav-item">
		        	<a id="ruangan" class="nav-link active" href="/ruangan">Ruangan</a>
		      	</li>
		    </ul>
		</div>
	</nav>
<p></p>
<div class="row bg-light text-dark" style="margin-right: 30px; margin-left: 30px; border: solid 1px lightgreen;">
  	<div class="col" style="border-right: solid 1px lightgreen;">
      <div class="container">
<table class="table table-hover">
    <tr>
        <th>NOMOR</th>
        <th>ID RUANGAN</th>
        <th>NO RUANGAN</th>
        <th>PASIEN</th>
        <th>DOKTER</th>
        <th>AKSI</th>
    </tr>
    @foreach($ruangan as $r)
    <tr>
        <td>{{$r->id}}</td>
        <td>{{$r->id_ruangan}}</td>
        <td>{{$r->no_ruangan}}</td>
        <td>{{$r->pasien}}</td>
        <td>{{$r->dokter}}</td>
        <td>
        <div class="btn-group" role="group" aria-label="Basic example">
                <a class="btn btn-warning" href="/ruangan/{{$r->id}}/edit">Edit</a>
        <form action="/ruangan{{$r->id}}" method="POST">
            @csrf
            @method('delete')
            <input class="btn btn-danger" type="submit" value="Delete">
        </form>
        
        </div> 
        </td>
    </tr>
    @endforeach
    
</table>
<a class="btn btn-primary" href="/ruangan/create">Tambah Data</a>
</div>
@endsection