@extends('layout.master')

@section('content')
<nav class="navbar navbar-expand-sm bg-success navbar-light">
		<div class="container-fluid">
		    <ul class="navbar-nav nav-tabs">

		    	<!-- LINK DOKTER -->

		      	<li class="nav-item" >
		        	<a class="nav-link" href="/dokter">Dokter</a>
		      	</li>

		      	<!-- LINK PASIEN -->

		     	<li class="nav-item">
		        	<a id="pasien" class="nav-link" href="/pasien">Pasien</a>
		      	</li>
		      	
		      	<!-- LINK OBAT -->

		      	<li class="nav-item">
		        	<a id="obat" class="nav-link active" href="/obat">Obat</a>
		      	</li>
		      	
		      	<!-- LINK RUANGAN -->

		      	<li class="nav-item">
		        	<a id="ruangan" class="nav-link" href="/ruangan">Ruangan</a>
		      	</li>
		    </ul>
		</div>
	</nav>
<p></p>
<div class="row bg-light text-dark" style="margin-right: 30px; margin-left: 30px; border: solid 1px lightgreen;">
  	<div class="col" style="border-right: solid 1px lightgreen;">
    <form action="/obat/store" method="POST">
        @csrf
    <h4>Tambah Data Obat</h4>

  	<!--INPUT NAMA OBAT-->

  	<div class="mb-3">
    	<label for="nama_obat" class="form-label">Nama Obat</label>
    	<input type="nama_obat" class="form-control" id="nama_obat" placeholder="Nama Obat" name="nama_obat">
  	</div>
  	
  	<!--INPUT JENIS OBAT-->

  	<div class="mb-3">
    	<label for="jenis_obat" class="form-label">Jenis Obat</label>
    	<input type="jenis_obat" class="form-control" id="jenis_obat" placeholder="Jenis Obat" name="jenis_obat">
  	</div>
  	
  	<!--INPUT KANDUNGAN OBAT-->

  	<div class="mb-3">
    	<label for="kandungan_obat" class="form-label">Kandungan Obat</label>
    	<input type="kandungan_obat" class="form-control" id="kandungan_obat" placeholder="Kandungan Obat" name="kandungan">
  	</div>

  	<!--INPUT KUANTITAS OBAT-->

  	<div class="mb-3">
    	<label for="kuantitas" class="form-label">Kuantitas</label>
    	<input type="kuantitas" class="form-control" id="kuantitas" placeholder="Kuantitas" name="kuantitas">
  	</div>
      <input type="submit" name="submit" value="Tambah">
</form>
</div>

   