<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\DokterController;
use App\Http\Controllers\PasienController;
use App\Http\Controllers\ObatController;
use App\Http\Controllers\RuanganController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/dokter',[DokterController::class,'index']);
Route::get('/dokter/create',[DokterController::class,'create']);
Route::post('/dokter/store',[DokterController::class,'store']);
Route::get('/dokter/{id_dokter}/edit',[DokterController::class,'edit']);
Route::delete('/dokter/{id_dokter}',[DokterController::class,'destroy']);
Route::get('/dokter/{id_dokter}',[DokterController::class,'update']);

Route::get('/pasien',[PasienController::class,'index']);
Route::get('/pasien/create',[PasienController::class,'create']);
Route::post('/pasien/store',[PasienController::class,'store']);
Route::get('/pasien/{id}/edit',[PasienController::class,'edit']);
Route::put('/pasien/{id}',[PasienController::class,'update']);
Route::delete('/pasien/{id}',[PasienController::class,'delete']);

Route::get('/obat',[ObatController::class,'index']);
Route::get('/obat/create',[ObatController::class,'create']);
Route::post('/obat/store',[ObatController::class,'store']);
Route::get('/obat/{id}/edit',[ObatController::class,'edit']);
Route::put('/obat/{id}',[ObatController::class,'update']);
Route::delete('/obat/{id}',[ObatController::class,'destroy']);

Route::get('/ruangan',[RuanganController::class,'index']);
Route::get('/ruangan/create',[RuanganController::class,'create']);
Route::post('/ruangan/store',[RuanganController::class,'store']);
Route::post('/ruangan/{id}/store',[RuanganController::class,'edit']);
Route::post('/ruangan/{id}',[RuanganController::class,'update']);
Route::delete('/ruangan/{id}',[RuanganController::class,'destroy']);

