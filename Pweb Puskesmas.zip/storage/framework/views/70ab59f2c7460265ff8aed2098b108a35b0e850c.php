

<?php $__env->startSection('content'); ?>
<nav class="navbar navbar-expand-sm bg-success navbar-light">
		<div class="container-fluid">
		    <ul class="navbar-nav nav-tabs">

		    	<!-- LINK DOKTER -->

		      	<li class="nav-item" >
		        	<a class="nav-link" href="/dokter">Dokter</a>
		      	</li>

		      	<!-- LINK PASIEN -->

		     	<li class="nav-item">
		        	<a id="pasien" class="nav-link active" href="/pasien">Pasien</a>
		      	</li>
		      	
		      	<!-- LINK OBAT -->

		      	<li class="nav-item">
		        	<a id="obat" class="nav-link" href="/obat">Obat</a>
		      	</li>
		      	
		      	<!-- LINK RUANGAN -->

		      	<li class="nav-item">
		        	<a id="ruangan" class="nav-link" href="/ruangan">Ruangan</a>
		      	</li>
		    </ul>
		</div>
	</nav>
<p></p>
<div class="row bg-light text-dark" style="margin-right: 30px; margin-left: 30px; border: solid 1px lightgreen;">
  	<div class="col" style="border-right: solid 1px lightgreen;">
      <div class="container">
<table class="table table-hover">
    <tr>
        <th>Nomor</th>
        <th>ID PASIEN</th>
        <th>NAMA</th>
        <th>ALAMAT</th>
        <th>NO.HP</th>
        <th>TANGGAL LAHIR</th>
        <th>JENIS KELAMIN</th>
        <th>RIWAYAT PENYAKIT</th>
        <th>PERAWAT</th>
        <th>OBAT</th>
        <th>AKSI</th>
    </tr>
    <?php $__currentLoopData = $pasien; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($p->id); ?></td>
        <td><?php echo e($p->id_pasien); ?></td>
        <td><?php echo e($p->nama_pasien); ?></td>
        <td><?php echo e($p->alamat_pasien); ?></td>
        <td><?php echo e($p->hp_pasien); ?></td>
        <td><?php echo e($p->tgl_lahir_pasien); ?></td>
        <td><?php echo e($p->jenis_kelamin); ?></td>
        <td><?php echo e($p->riwayat_penyakit); ?></td>
        <td><?php echo e($p->perawat); ?></td>
        <td><?php echo e($p->obat); ?></td>
        <td>
        <div class="btn-group" role="group" aria-label="Basic example">   
                <a class="btn btn-warning" href="/pasien/<?php echo e($p->id); ?>/edit">Edit</a>
        <form action="/pasien<?php echo e($p->id); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('delete'); ?>
            <input class="btn btn-danger" type="submit" value="Delete">
        </form>
        
        </div> 
        </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
</table>
<a class="btn btn-primary" href="/pasien/create">Tambah Data</a>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\pweb\resources\views/pasien/index.blade.php ENDPATH**/ ?>