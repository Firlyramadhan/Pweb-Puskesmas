

<?php $__env->startSection('content'); ?>
<nav class="navbar navbar-expand-sm bg-success navbar-light">
		<div class="container-fluid">
		    <ul class="navbar-nav nav-tabs">

		    	<!-- LINK DOKTER -->

		      	<li class="nav-item" >
		        	<a class="nav-link" href="/dokter">Dokter</a>
		      	</li>

		      	<!-- LINK PASIEN -->

		     	<li class="nav-item">
		        	<a id="pasien" class="nav-link" href="/pasien">Pasien</a>
		      	</li>
		      	
		      	<!-- LINK OBAT -->

		      	<li class="nav-item">
		        	<a id="obat" class="nav-link active" href="/obat">Obat</a>
		      	</li>
		      	
		      	<!-- LINK RUANGAN -->

		      	<li class="nav-item">
		        	<a id="ruangan" class="nav-link" href="/ruangan">Ruangan</a>
		      	</li>
		    </ul>
		</div>
	</nav>
<p></p>
<div class="row bg-light text-dark" style="margin-right: 30px; margin-left: 30px; border: solid 1px lightgreen;">
  	<div class="col" style="border-right: solid 1px lightgreen;">
      <div class="container">
      <table class="table table-hover">
    <tr>
        <th>ID Obat</th>
        <th>NAMA OBAT</th>
        <th>JENIS OBAT</th>
        <th>KANDUNGAN</th>
        <th>KUANTITAS</th>
        <th>AKSI</th>
    </tr>
    <?php $__currentLoopData = $obat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($o->id); ?></td>
        <td><?php echo e($o->nama_obat); ?></td>
        <td><?php echo e($o->jenis_obat); ?></td>
        <td><?php echo e($o->kandungan); ?></td>
        <td><?php echo e($o->kuantitas); ?></td>
        <td>
            <div class="btn-group" role="group" aria-label="Basic example"> 
                <a class="btn btn-warning" href="/obat/<?php echo e($o->id); ?>/edit">Edit</a>
        <form action="/obat/<?php echo e($o->id); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('delete'); ?>
            <input class="btn btn-danger" type="submit" value="Delete">
        </form>
        
        </div> 
        </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
</table>
<a class="btn btn-primary" href="/obat/create">Tambah Data</a>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\pweb\resources\views/obat/index.blade.php ENDPATH**/ ?>