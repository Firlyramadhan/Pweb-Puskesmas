

<?php $__env->startSection('content'); ?>
<nav class="navbar navbar-expand-sm bg-success navbar-light">
		<div class="container-fluid">
		    <ul class="navbar-nav nav-tabs">
                <!-- LINK DOKTER -->

		      	<li class="nav-item" >
		        	<a class="nav-link active" href="/dokter">Dokter</a>
		      	</li>

		      	<!-- LINK PASIEN -->

		     	<li class="nav-item">
		        	<a id="pasien" class="nav-link" href="/pasien" >Pasien</a>
		      	</li>
		      	
		      	<!-- LINK OBAT -->

		      	<li class="nav-item">
		        	<a id="obat" class="nav-link" href="/obat">Obat</a>
		      	</li>
		      	
		      	<!-- LINK RUANGAN -->

		      	<li class="nav-item">
		        	<a id="ruangan" class="nav-link" href="/ruangan">Ruangan</a>
		      	</li>
		    </ul>
		</div>
	</nav>
<p></p>
<div class="row bg-light text-dark" style="margin-right: 30px; margin-left: 30px; border: solid 1px lightgreen;">
  	<div class="col" style="border-right: solid 1px lightgreen;">
<h4>Tambah Data Dokter</h4>
<form action="/dokter/store" method="POST">
    <?php echo csrf_field(); ?>
<div class="mb-3 mt-3">
    	<label for="id_dokter" class="form-label">Id Dokter:</label>
    	<input type="text" class="form-control" id="id dokter" placeholder="Id dokter" name="id">
  	</div>

  	<!--INPUT NAMA DOKTER-->

  	<div class="mb-3">
    	<label for="nama_dokter" class="form-label">Nama Dokter</label>
    	<input type="nama dokter" class="form-control" id="nama_dokter" placeholder="Nama Dokter" name="nama_dokter">
  	</div>
  	
  	<!--INPUT ALAMAT DOKTER-->

  	<div class="mb-3">
    	<label for="alamat_dokter" class="form-label">Alamat Dokter</label>
    	<input type="alamat_dokter" class="form-control" id="alamat_dokter" placeholder="Alamat Dokter" name="alamat_dokter">
  	</div>
  	
  	<!--INPUT HP DOKTER-->

  	<div class="mb-3">
    	<label for="hp_dokter" class="form-label">Hp Dokter</label>
    	<input type="hp_dokter" class="form-control" id="hp_dokter" placeholder="Hp Dokter" name="hp_dokter">
  	</div>

  	<!--INPUT TANGGAL LAHIR DOKTER-->

  	<div class="mb-3">
    	<label for="tgl_dokter" class="form-label">Tanggal Lahir Dokter</label>
    	<input type="date" class="form-control" id="tgl_dokter" placeholder="Tanggal Lahir Dokter" name="tgl_lahir_dokter">
  	</div>

  	<!--CHECK JENIS KELAMIN DOKTER-->

  	<div class="mb-3">
    	<label for="jenis_kelamin" class="form-label">Jenis Kelamin</label>
    	<select name="jenis_kelamin">
  		<option selected>Pilih Jenis Kelamin</option>
  		<option value="1">Laki-laki</option>
  		<option value="2">Perempuan</option>
        </select>
  	</div>

	<!--INPUT SPESIALIS DOKTER-->

  	<div class="mb-3">
    	<label for="spesialis_dokter" class="form-label">Spesialis</label>
    	<input type="spesialis_dokter" class="form-control" id="spesialis_dokter" placeholder="Spesialis" name="spesialis">
  	</div>

  	<!--INPUT JEM KERJA DOKTER-->

  	<div class="mb-3">
    	<label for="jam_dokter" class="form-label">Jam Kerja Dokter</label>
    	<select class="form-select" aria-label="Default select example">
  		<option selected>Pilih Jam Kerja</option>
  		<option value="1">08:00-16:00</option>
  		<option value="2">16:00-23:00</option>
</select>
  	</div>
      <input type="submit" name="submit" value="Tambah">
      </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\pweb\resources\views/dokter/create.blade.php ENDPATH**/ ?>