

<?php $__env->startSection('content'); ?>
<nav class="navbar navbar-expand-sm bg-success navbar-light">
		<div class="container-fluid">
		    <ul class="navbar-nav nav-tabs">

		    	<!-- LINK DOKTER -->

		      	<li class="nav-item" >
		        	<a class="nav-link" href="/dokter">Dokter</a>
		      	</li>

		      	<!-- LINK PASIEN -->

		     	<li class="nav-item">
		        	<a id="pasien" class="nav-link" href="/pasien">Pasien</a>
		      	</li>
		      	
		      	<!-- LINK OBAT -->

		      	<li class="nav-item">
		        	<a id="obat" class="nav-link" href="/obat">Obat</a>
		      	</li>
		      	
		      	<!-- LINK RUANGAN -->

		      	<li class="nav-item">
		        	<a id="ruangan" class="nav-link active" href="/ruangan">Ruangan</a>
		      	</li>
		    </ul>
		</div>
	</nav>
<p></p>
<div class="row bg-light text-dark" style="margin-right: 30px; margin-left: 30px; border: solid 1px lightgreen;">
  	<div class="col" style="border-right: solid 1px lightgreen;">
      <form action="/ruangan/store" method="POST">
          <?php echo csrf_field(); ?>
      <!--INPUT ID RUANGAN-->

  	<div class="mb-3 mt-3">
    	<label for="id_ruangan" class="form-label">Id Ruangan</label>
    	<input type="id_ruangan" class="form-control" id="id_ruangan" placeholder="id ruangan" name="id_ruangan">
  	</div>
      <!--INPUT NO RUANGAN-->

  	<div class="mb-3 mt-3">
    	<label for="id_ruangan" class="form-label">N0 Ruangan</label>
    	<input type="id_ruangan" class="form-control" id="id_ruangan" placeholder="No Ruangan" name="no_ruangan">
  	</div>

    <!--INPUT NAMA PASIEN-->

  	<div class="mb-3">
    	<label for="id_pasien" class="form-label">Pasien</label>
    	<input type="id_pasien" class="form-control" id="id_pasien" placeholder="Pasien" name="pasien">
  	</div>

  	<!--INPUT NAMA DOKTER-->

  	<div class="mb-3">
    	<label for="id_dokter" class="form-label">Dokter</label>
    	<input type="id_dokter" class="form-control" id="id_dokter" placeholder="Dokter" name="dokter">
  	</div>
  	<input type="submit" name="submit" value="Tambah">
</form>
</div>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\pweb\resources\views/ruangan/create.blade.php ENDPATH**/ ?>